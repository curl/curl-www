This archive contains single patches for every version of curl affected by
CVE-2023-38545 "SOCKS5 heap buffer overflow".

Bug: https://curl.se/docs/CVE-2023-38545.html

The affected curl versions are 7.69.0 - 8.3.0. Each patch applies to part of
that range, as documented below. For example, the 7.73.0 patch has a range of
7.73.0 - 7.74.0 and therefore could be applied to 7.74.0 like
`git checkout curl-7_74_0; git am CVE-2023-38545_7.73.0.patch`.

CVE-2023-38545_7.69.0.patch
---------------------------
This patch applies to curl versions 7.69.0 - 7.72.0.

CVE-2023-38545_7.73.0.patch
---------------------------
This patch applies to curl versions 7.73.0 - 7.74.0.

CVE-2023-38545_7.75.0.patch
---------------------------
This patch applies to curl versions 7.75.0 - 7.76.0.

CVE-2023-38545_7.76.1.patch
---------------------------
This patch applies to curl versions 7.76.1 - 7.77.0.

CVE-2023-38545_7.78.0.patch
---------------------------
This patch applies to curl versions 7.78.0 - 7.80.0.

CVE-2023-38545_7.81.0.patch
---------------------------
This patch applies to curl versions 7.81.0 - 7.86.0.

CVE-2023-38545_7.87.0.patch
---------------------------
This patch applies to curl versions 7.87.0 - 8.1.2.

CVE-2023-38545_8.2.0.patch
--------------------------
This patch applies to curl versions 8.2.0 - 8.3.0.

CVE-2023-38545_8.4.0-DEV.patch
------------------------------
This patch applies to curl 65b563a9 (8.4.0-DEV) and later. If you are using a
development build of curl that came after 8.3.0 but before 65b563a9 then use
CVE-2023-38545_8.2.0.patch.
