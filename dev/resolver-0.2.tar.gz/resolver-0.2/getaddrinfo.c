/*************************************************************************
 *
 * $Id:$
 *
 * Copyright (C) 2000 Bjorn Reese.
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE AUTHORS AND
 * CONTRIBUTORS ACCEPT NO RESPONSIBILITY IN ANY CONCEIVABLE MANNER.
 *
 ************************************************************************/

/*
 * References:
 *
 * Robert Gillian, Susan Thomson, Jim Bound, and Richard Stevens
 * "Basic Socket Interface Extensions for IPv6"
 * RFC 2553, March 1999
 * http://www.ietf.org/rfc/rfc2553.txt
 *
 * The Open Group.
 * Technical Standard: Networking Services (XNS) Issue 5.2, Draft 4,
 * November 1999
 * http://www.opengroup.org/orc/DOCS/XNS/
 *
 * Richard Stevens
 * "Unix Network Programming. Networking APIs: Socket and XTI"
 * 2nd edition, volume 1, Prentice Hall, 1998
 */

static const char rcsid[] = "@(#)$Id:$";

#include <stdio.h>

#include "getaddrinfo.h"
#include <assert.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/utsname.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <netdb.h>
#ifdef SUPPORT_IP6
# include <resolv.h>
#endif

#ifndef INADDR_NONE
# define INADDR_NONE (unsigned long)(~0)
#endif

#ifndef MAXHOSTPATH
# define MAXHOSTPATH 108
#endif
#define SYS_ERROR -1

#define strequal(x,y) (0 == strcmp((x), (y)))

/*************************************************************************
 * Prototypes
 */
int inet_pton(int, const char *, void *);


/*************************************************************************
 * GetAddrInfo
 *
 * AF_UNSPEC not implemented (although defined in Posix.1g)
 * AF_INET6 not fully implemented or tested
 */
int GetAddrInfo(const char *hostname,
		const char *service,
		const struct addrinfo *hints,
		struct addrinfo **ppResult)
{
  int family, flags, proto;
  const char *host;
  unsigned long in;
  struct hostent *h;
  struct addrinfo *p, *pp;

  *ppResult = NULL;
  if (hints) {
    flags = hints->ai_flags;
    family = hints->ai_family;
    proto = hints->ai_protocol ? hints->ai_protocol : SOCK_STREAM;
  } else {
    flags = 0;
    family = AF_INET;
    proto = SOCK_STREAM;
  }

  if (hostname && ('/' == *hostname) &&
      (strequal(hostname, "/unix") || strequal(hostname, "/local"))) {
    family = AF_LOCAL;
  }

  switch (family) {
    
  case AF_INET:
    if (hostname && *hostname)
      host = hostname;
    else
      host = (flags & AI_PASSIVE) ? "0.0.0.0" : "localhost";
    break;
    
#ifdef SUPPORT_IP6
  case AF_INET6:
    if (hostname && *hostname)
      host = hostname;
    else
      host = (flags & AI_PASSIVE) ? "0::0" : "0::1";
    break;
#endif
    
  case AF_LOCAL:
    return GetAddrInfoLocal(service, hints, ppResult);
    
  default:
    host = (hostname && *hostname) ? hostname : "0.0.0.0";
    break;
  }

  in = inet_addr(host);
  if (INADDR_NONE == in) {

    /* Forward lookup */
    switch (family) {
	
    case AF_INET:
#ifdef SUPPORT_IP6
    case AF_INET6:
#endif
      {
#if defined(SUPPORT_IP6) && defined(RES_USE_INET6)
	if (! (_res.options & RES_INIT))
	  res_init();
	if (AF_INET6 = family)
	  _res.options |= RES_USE_INET6;
	else
	  _res.options &= RES_USE_INET6;
#endif
	h = gethostbyname(host);
	if (h) {
	  int i;
	  for (i = 0; h->h_addr_list[i]; ++i) {
	    p = (struct addrinfo *)calloc(1, sizeof(struct addrinfo));
	    if (p) {
	      if (NULL == *ppResult)
		*ppResult = p;
	      else
		pp->ai_next = p;
	      /* From lint: (156) warning: variable may be used before set: pp */
	      pp = p;
	      p->ai_flags = flags;
	      p->ai_family = family;
	      p->ai_protocol = proto;
#ifdef SUPPORT_IP6
	      if (AF_INET6 == family)
		p->ai_addrlen = sizeof(struct sockaddr_in6);
	      else
#endif
		p->ai_addrlen = sizeof(struct sockaddr_in);
	      
	      p->ai_addr = (struct sockaddr *)calloc(1, p->ai_addrlen);
	      if (p->ai_addr) {
		struct sockaddr_in *s = (struct sockaddr_in *)p->ai_addr;
		memcpy(&s->sin_addr, h->h_addr_list[i], h->h_length);
	      }
	    }
	  } /* for */
	  (*ppResult)->ai_canonname = strdup(h->h_name);
	  
	} else {
	  /* Map the h_errno to some reasonable errno code */
	  switch (h_errno) {
	      
#ifdef NETDB_INTERNAL
	  case NETDB_INTERNAL:
	    /* errno is set correctly already */
	    break;
#endif
#ifdef HOST_NOT_FOUND
	  case HOST_NOT_FOUND:
	    errno = EHOSTUNREACH;
	    break;
#endif
#ifdef TRY_AGAIN
	  case TRY_AGAIN:
	    errno = EAGAIN;
	    break;
#endif
#ifdef NO_RECOVERY
	  case NO_RECOVERY:
	    errno = ECONNREFUSED;
	    break;
#endif
#ifdef NO_DATA
	  case NO_DATA:
	    errno = ENOENT;
	    break;
#endif
#if defined(NO_ADDRESS) && !(defined(NO_DATA) && NO_ADDRESS == NO_DATA)
	  case NO_ADDRESS:
	    errno = 0;
	    break;
#endif
	  default:
	    break;
	  }
	}
      }
      
    default:
      break;
    }

  } else {

    /* Reverse lookup */
    switch (family) {
	
    case AF_INET:
      {
	struct in_addr inaddr;

	/* FIXME: We should try gethostbyaddr() first, and continue
	 * below if it fails
	 */
	if (inet_pton(AF_INET, host, &inaddr)) {
	  p = (struct addrinfo *)calloc(1, sizeof(struct addrinfo));
	  if (p) {
	    if (NULL == *ppResult)
	      *ppResult = p;
	    else
	      pp->ai_next = p;
	    pp = p;
	    p->ai_flags = flags;
	    p->ai_family = AF_INET;
	    p->ai_protocol = proto;
	    p->ai_canonname = strdup(host);
	    p->ai_addrlen = sizeof(struct sockaddr_in);
	    p->ai_addr = (struct sockaddr *)calloc(1, p->ai_addrlen);
	    if (p->ai_addr) {
	      struct sockaddr_in *s = (struct sockaddr_in *)p->ai_addr;
	      memcpy(&s->sin_addr, &inaddr, sizeof(inaddr));
	    }
	  }
	}
	break;
      }
      
#ifdef SUPPORT_IP6
    case AF_INET6:
      /* Missing */
      break;
#endif
      
    default:
      break;
    }
  }

  return (NULL == *ppResult) ? SYS_ERROR : 0;
}


/*************************************************************************
 * GetAddrInfoLocal
 */
int GetAddrInfoLocal(const char *pathname, const struct addrinfo *hints,
		     struct addrinfo **ppResult)
{
  struct addrinfo *p;

  assert(pathname != NULL);

  p = (struct addrinfo *)calloc(1, sizeof(struct addrinfo));
  if (p) {
    *ppResult = p;
    p->ai_family = AF_LOCAL;
    p->ai_protocol = SOCK_STREAM;
    p->ai_canonname = strdup("/local");
    p->ai_addrlen = sizeof(struct sockaddr_un);
    p->ai_addr = (struct sockaddr *)calloc(1, p->ai_addrlen);
    if (p->ai_addr) {
      char *target = ((struct sockaddr_un *)p->ai_addr)->sun_path;
      strncpy(target, pathname, p->ai_addrlen - 1);
      target[p->ai_addrlen] = (char)0;
      ((struct sockaddr_un *)p->ai_addr)->sun_family = p->ai_family;
      
      if (hints && (hints->ai_flags & AI_CANONNAME)) {
	struct utsname info;

	if (SYS_ERROR != uname(&info)) {
	  (*ppResult)->ai_canonname = strdup(info.nodename);
	}
      }
      if (hints && (hints->ai_flags & AI_PASSIVE)) {
	(void)unlink(pathname);
	errno = 0; /* Ignore errors */
      }
      return 0;
    }
    FreeAddrInfo(*ppResult);
  }
  return SYS_ERROR;
}

/*************************************************************************
 * FreeAddrInfo
 */
void FreeAddrInfo(struct addrinfo *addr)
{
  struct addrinfo *next;

  assert(addr != NULL);

  while (addr) {
    next = addr->ai_next;

    if (addr->ai_addr) {
      free(addr->ai_addr);
    }
    if (addr->ai_canonname) {
      free(addr->ai_canonname);
    }
    free(addr);
    
    addr = next;
  }
}

/*************************************************************************
 * SetPort
 */
int SetPort(struct addrinfo *head, int port)
{
  /* NB: 'port' must be in network order */
  struct addrinfo *addr;

  assert(head != NULL);

  for (addr = head; (addr); addr = addr->ai_next) {
    
    switch (addr->ai_family) {
	
    case AF_INET:
      ((struct sockaddr_in *)addr->ai_addr)->sin_port = (short)port;
      break;
	  
    default:
      break;
    }
  }
  return 0;
}

/*************************************************************************
 * GetService
 */
int GetService(struct addrinfo *head, const char *service)
{
  struct servent *pResult;
  
  assert(service != NULL);
  assert(head != NULL);

  if (isdigit(service[0])) {
    (void)SetPort(head, htons(atoi(service)));
  } else {
      
    switch (head->ai_socktype) {
	
    case SOCK_STREAM:
      pResult = getservbyname(service, "tcp");
      if (pResult) {
	(void)SetPort(head, pResult->s_port);
      }
      break;
	  
    case SOCK_DGRAM:
      pResult = getservbyname(service, "udp");
      if (pResult) {
	(void)SetPort(head, pResult->s_port);
      }
      break;
      
    default:
      break;
    }
  }
  return 0;
}
