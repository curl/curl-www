/*************************************************************************
 *
 * $Id:$
 *
 * Copyright (C) 2000 Bjorn Reese.
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE AUTHORS AND
 * CONTRIBUTORS ACCEPT NO RESPONSIBILITY IN ANY CONCEIVABLE MANNER.
 *
 ************************************************************************/

#ifndef H_RESOLVER_RESOLVER
#define H_RESOLVER_RESOLVER

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include "getaddrinfo.h"

enum {
  /* Return codes */
  RESOLVER_ERROR   = -1,
  RESOLVER_OK      =  0,
  RESOLVER_WORKING =  1,
  
  /* Initialization */
  RESOLVER_INIT_DEFAULT = 0,
  RESOLVER_INIT_WITHOUT_SIGNALHANDLER = 1 << 0,
  
  /* Lookup request */
  RESOLVER_SERVICE = 1 << 0,  /* Find service instead of host */
  RESOLVER_QUEUE   = 1 << 1,  /* Queue several requests */
  RESOLVER_BLOCK   = 1 << 2,  /* Wait for result */

  /* Retrieval */
  RESOLVER_FORCE   = 1 << 0, /* Get now or cancel */
  RESOLVER_CANCEL  = 1 << 1, /* Cancel the request */
};

/*************************************************************************
 * Starts a Domain Name Service lookup query.
 *
 * RETURNS:
 *  If data is available in the addrinfo struct a 0 is returned,
 *  otherwise if an error occured -1 is returned and errno is set
 *  errno:
 *    0, request is being processed
 *    EWOULDBLOCK, request cannot be processed now
 */
int ResolverLookup(char *name, unsigned int flags, struct addrinfo **);


/*************************************************************************
 * Frees any resouces associated with a resolver data structure
 */
void ResolverFree(struct addrinfo *);


/*************************************************************************
 * The initialisation must be called before the first use of the resolver.
 */
void ResolverInit(unsigned int flags);


/*************************************************************************
 * The finalizer must be called to clean-up everything after the resolver
 * has been used for the last time.
 */
void ResolverFini(void);


/*************************************************************************
 * Returns a handle to wait on data with select() or poll().
 *
 * Do not read from or write to this handle.
 */
int ResolverHandle(void);


/*************************************************************************
 * Integration into application SIGCHLD signal handler.
 *
 * The resolver will start its own child process, and must be notified if
 * this child process terminates. Per default it will install its own
 * SIGCHLD signal handler for this purpose.
 *
 * If your application has its own SIGCHLD signal handler, then you must
 * specify the RESOLVER_INIT_WITHOUT_SIGNALHANDLER flag in the call to
 * ResolverInit(), and your application must notify the resolver itself.
 *
 * Two auxiliary functions are provided to keep the resolver informed
 * about the state of its child process. These must be used within the
 * SIGCHLD signal handler of the application as follows:
 *
 *   pid = waitpid((pid_t)-1, &status, WNOHANG);
 *   ...
 *   if (pid == ResolverPid())
 *     ResolverTerminated();
 */

/* Async-safe auxiliary function.
 *
 * Use within own SIGCHLD signal handler, to obtain the process identifier
 * of the resolver child.
 */
pid_t ResolverPid(void);

/* Async-safe auxiliary function.
 *
 * Use within own SIGCHLD signal handler, to indicate that the resolver
 * child process had terminated.
 */
void ResolverTerminated(void);

#endif /* H_RESOLVER_RESOLVER */
