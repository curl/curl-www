/*************************************************************************
 *
 * $Id:$
 *
 * Copyright (C) 2000 Bjorn Reese.
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE AUTHORS AND
 * CONTRIBUTORS ACCEPT NO RESPONSIBILITY IN ANY CONCEIVABLE MANNER.
 *
 ************************************************************************/

#ifndef H_RESOLVER_GETADDRINFO
#define H_RESOLVER_GETADDRINFO

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

/* AF_LOCAL is the Posix equivalent of AF_UNIX */
#if !defined(AF_LOCAL)
# define AF_LOCAL AF_UNIX
#endif

#if !defined(AI_PASSIVE)
enum {
  /* addrinfo.ai_flags */
  AI_PASSIVE     = 1 << 0,
  AI_CANONNAME   = 1 << 1,
  AI_NUMERICHOST = 1 << 2,
};

struct addrinfo {
  int ai_flags;
  int ai_family;
  int ai_socktype;
  int ai_protocol;
  size_t ai_addrlen;
  char *ai_canonname;
  struct sockaddr *ai_addr;
  struct addrinfo *ai_next;
};
#endif

int GetAddrInfo(const char *hostname,
		const char *servicename,
		const struct addrinfo *hints,
		struct addrinfo **result);
int GetAddrInfoLocal(const char *pathname,
		     const struct addrinfo *hints,
		     struct addrinfo **result);
void FreeAddrInfo(struct addrinfo *);
int GetService(struct addrinfo *head,
	       const char *pService);

#endif /* H_RESOLVER_GETADDRINFO */
