/*************************************************************************
 *
 * $Id:$
 *
 * Copyright (C) 2000 Bjorn Reese.
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE AUTHORS AND
 * CONTRIBUTORS ACCEPT NO RESPONSIBILITY IN ANY CONCEIVABLE MANNER.
 *
 ************************************************************************/

#ifndef H_RESOLVER_LIST
#define H_RESOLVER_LIST

#include <stdlib.h>
#include <assert.h>

/*************************************************************************
 * LIST
 *
 * Description:
 *
 *  Define a list. This must be used in a struct definition. For example
 *
 *    typedef struct Socket {
 *      int state;
 *      LIST(struct Socket, link);
 *    } socket_T;
 *
 *  A linked list consist of three elements:
 *
 *    _next points to the next entry. NULL means it is the last entry
 *          on the list
 *    _prev points to the previous entry. NULL means it is the first
 *          entry on the list
 *    _last points to the last entry on the list. This is only set for
 *          the first entry on the list -- all other entries have this
 *          set to NULL
 */
#define LIST(type, name) \
  type * ##name## _next; \
  type * ##name## _prev; \
  type * ##name## _last

/*************************************************************************
 * LIST_APPEND
 *
 * Description:
 *  Append an entry to a list. If the list is empty then it will be
 *  created. If 'list' (the 3rd argument) is not the start of the list,
 *  then this 'entry' will be inserted immediately after the 'list'
 *  entry.
 *
 * Implementation:
 *
 *  if list is empty then
 *    make this the first entry
 *    let _last point to itself
 *  else if first entry and _last is unset then
 *    let _last point to itself
 *    (* this special case is added to allow initialization of a list
 *       with LIST_APPEND(socket_T, link, self, self); *)
 *  else
 *    if first entry then
 *      let _before be _last
 *      let _last point to this entry
 *    else
 *      if list is not the head then
 *        find head and set _last to this entry
 *      endif
 *      let _before point to the list
 *    endif
 *    insert entry
 *  endif
 */
#define LIST_APPEND(type, name, list, entry) \
  do { \
    assert((entry) != NULL); \
    if ((list) == NULL) { \
      (list) = entry; \
      (list)-> ##name## _last = entry; \
    } else if (((list)-> ##name## _prev == NULL) && ((list)-> ##name## _last == NULL)) { \
      (list)-> ##name## _last = list; \
    } else { \
      type * ##name## _before; \
      type * ##name## _after; \
      if ((list)-> ##name## _prev == NULL) { \
	##name## _before = (list)-> ##name## _last; \
	(list)-> ##name## _last = entry; \
      } else { \
	if ((list)-> ##name## _next == NULL) { \
	  for (##name## _before = (list); \
               ##name## _before -> ##name## _prev != NULL; \
	       ##name## _before = ##name## _before -> ##name## _prev); \
	  ##name## _before -> ##name## _last = entry; \
	} \
	##name## _before = list; \
      } \
      ##name## _after = ##name## _before -> ##name## _next; \
      (entry)-> ##name## _next = ##name## _after; \
      (entry)-> ##name## _prev = ##name## _before; \
      ##name## _before -> ##name## _next = entry; \
      if (##name## _after != NULL) { \
	##name## _after -> ##name## _prev = entry; \
      } \
    } \
  } while (0)

/*************************************************************************
 * LIST_REMOVE
 *
 * Description:
 *  Remove an arbitrary entry for a list
 */
#define LIST_REMOVE(type, name, list, entry) \
 do { \
    assert((entry) != NULL); \
    assert((list) != NULL); \
    if ((list)-> ##name## _last == (list)) { \
      list = NULL; \
    } else { \
      type * ##name## _before; \
      type * ##name## _after; \
      if ((list)-> ##name## _last == (entry)) { \
	(list)-> ##name## _last = (entry)-> ##name## _prev; \
      } \
      ##name## _before = (entry)-> ##name## _prev; \
      ##name## _after = (entry)-> ##name## _next; \
      if (##name## _before != NULL) { \
        ##name## _before -> ##name## _next = ##name## _after; \
      } else { \
	if (##name## _after != NULL) { \
	  ##name## _after -> ##name## _last = (entry)-> ##name## _last; \
	} \
	list = ##name## _after; \
      } \
      if (##name## _after != NULL) { \
	##name## _after -> ##name## _prev = ##name## _before; \
      } \
    } \
  } while (0)

/*************************************************************************
 * LIST_FIRST
 *
 * Description:
 *  Get the first entry on a list
 */
#define LIST_FIRST(type, name, list) (type *)(list)

/*************************************************************************
 * LIST_NEXT
 *
 * Description:
 *  Get the next entry on a list
 */
#define LIST_NEXT(type, name, list) \
     (type *)(((list) == NULL) ? NULL : (list)-> ##name## _next)

#endif /* H_RESOLVER_LIST */
