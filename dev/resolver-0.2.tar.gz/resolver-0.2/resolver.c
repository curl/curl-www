/*************************************************************************
 *
 * $Id:$
 *
 * Copyright (C) 2000 Bjorn Reese.
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE AUTHORS AND
 * CONTRIBUTORS ACCEPT NO RESPONSIBILITY IN ANY CONCEIVABLE MANNER.
 *
 ************************************************************************/

static const char rcsid[] = "@(#)$Id:$";

/* FIXME:
 *  - write() must check return value (if child terminated, no SIGCHLD
 *    handler was installed, and the application has forgotten to handle
 *    the signal appropriately)
 *  - SUPPORT_IP6 has never been tested
 */

/*
 * All communication between the parent process and the child process
 * is done via a simple ASCII line-based protocol.
 *
 * > L = Lookup (host, service, family)
 *
 * < Z = Start
 * < N = Hostname (canonname)
 * < A = Address (numerical address)
 * < X = Stop (host)
 * < E = Error (errno)
 */

#include "resolver.h"
#include "list.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#define strequal(x,y) (strcmp((x),(y))==0)

#define SYS_ERROR -1
#define MAX_HOSTNAME 256
#define MAX_BUFFER 512
#ifndef FALSE
# define FALSE (0 == 1)
# define TRUE (!FALSE)
#endif
#define NIL ((char)0)

/*************************************************************************
 * Types
 */

struct ResolverRequest
{
  LIST(struct ResolverRequest, link);
  char *name;
  unsigned long flags;
  struct addrinfo *address;
};

struct Resolver {
  int is_running;
  pid_t pid;
  int read_handle;
  int write_handle;
  FILE *read_filehandle;
  struct ResolverRequest *first;
};

/*************************************************************************
 * Prototypes
 */
const char *inet_ntop(int, const void *, char *, size_t);

/*************************************************************************
 * Global
 */

/* It is not necessary to put the global data in the struct, but
 * it will ease further extensions to multiple resolvers.
 */
static struct Resolver globalResolver;

static struct Resolver *GlobalGetResolver(void)
{
  return &globalResolver;
}

/*************************************************************************
 *
 * Private functions
 *
 ************************************************************************/
									  
/*************************************************************************
 * ChildHandler
 *
 * This signal handler catches children process which are exiting,
 * and disables the resolver if its child exits.
 */
static void ChildHandler(int sig)
{
  volatile int errno_save;
  pid_t pid;
  int status;
  struct Resolver *resolver;

  assert(sig == SIGCHLD); /* Sanity check */

  /* waitpid() may change errno, so we save it to avoid side-effects
   * outside the signal handler
   */
  errno_save = errno;

  resolver = GlobalGetResolver();
  pid = waitpid(resolver->pid, &status, 0);
  if (pid == resolver->pid) {
    /* The resolver child has exited */
    resolver->is_running = FALSE;
    resolver->pid = SYS_ERROR;
  }
  errno = errno_save;
}

/*************************************************************************
 * ChildProcess
 *
 * This is the main function of the DNS lookup process.
 */
static void ChildProcess(struct Resolver *self, int read_fd, int write_fd)
{
  FILE *child_read_filehandle = NULL;
  FILE *child_write_filehandle = NULL;
  char host[MAX_HOSTNAME];
  char service[MAX_HOSTNAME];
  char name[MAX_HOSTNAME];
  int family;
  char buffer[MAX_BUFFER] = "";

  /* For debugging the child process */
/*    int waiting = 1; */
/*    while (waiting); */

  /* Get FILE descriptors so we can use stdio */
  child_read_filehandle = fdopen(read_fd, "r");
  child_write_filehandle = fdopen(write_fd, "w");
  if ((child_read_filehandle) && (child_write_filehandle)) {
    
    for (;;) {
      errno = 0;
      
      /* Read lookup request from pipe */
      if (NULL != fgets(buffer, sizeof(buffer), child_read_filehandle)) {
	
	/* Parse lookup request */
	if (3 == sscanf(buffer, "L %s %s %d",
			host, service, &family))
	  {
	    
	    struct addrinfo *result = NULL;
	    struct addrinfo *address;
	    struct addrinfo hint;
	    
	    memset(&hint, NIL, sizeof(hint));
	    hint.ai_family = family;
	    
	    if (SYS_ERROR == GetAddrInfo(host, service, &hint, &result)) {
	      /* Return an error */
	      fprintf(child_write_filehandle, "E %d\n", errno);
	    } else {
	      /* Return the result of the DNS lookup */
	      fprintf(child_write_filehandle, "Z\n");
	      if (result->ai_canonname) {
		fprintf(child_write_filehandle, "N %s\n",
			result->ai_canonname);
	      }
	    
	      for (address = result; (address); address = address->ai_next) {
	      
		switch (result->ai_family) {
		case AF_INET:
		  if (inet_ntop(AF_INET,
				&((struct sockaddr_in *)address->ai_addr)->sin_addr,
				name, sizeof(name))) {
		    fprintf(child_write_filehandle, "A %d %d %s\n",
			    AF_INET,
			    ntohs(((struct sockaddr_in *)address->ai_addr)->sin_port),
			    name);
		  }
		  break;
		
#if defined(SUPPORT_IP6)
		case AF_INET6:
		  if (inet_ntop(AF_INET6,
				&((struct sockaddr_in6 *)address->ai_addr)->sin_addr,
				name, sizeof(name))) {
		    fprintf(child_write_filehandle, "A %d %d %s\n",
			    AF_INET6,
			    ntohs((struct sockaddr_in6 *)(address->ai_addr)->sin_port),
			    name);
		  }
		  break;
#endif
		default:
		  break;
		}
	      }
	      FreeAddrInfo(result);
	    }
	    /* End of record */
	    fprintf(child_write_filehandle, "X %s\n", host);
	    /* Force it through the pipe */
	    (void)fflush(child_write_filehandle);
	  }
      }
    }
  }
}

/*************************************************************************
 * Launch
 *
 * Attempt to start the child process, which is doing the actual DNS
 * lookups.
 *
 * Output:
 *  SYS_ERROR on failure
 *  PID of child otherwise
 */
static int Launch(struct Resolver *self)
{
#define READABLE_FD 0
#define WRITABLE_FD 1
  int fd_child[2];
  int fd_parent[2];

  if (SYS_ERROR != pipe(fd_parent)) {
    if (SYS_ERROR != pipe(fd_child)) {

      self->pid = fork();
      switch (self->pid) {
	
      case SYS_ERROR:
	break;

      case 0: /* Child */
	(void)close(fd_child[READABLE_FD]);
	(void)close(fd_parent[WRITABLE_FD]);
	ChildProcess(self, fd_parent[READABLE_FD], fd_child[WRITABLE_FD]);
	/* We should never get here, but just in case... */
	_exit(1);
	break;

      default: /* Parent */
	(void)close(fd_parent[READABLE_FD]);
	(void)close(fd_child[WRITABLE_FD]);
	self->read_handle = fd_child[READABLE_FD];
	self->write_handle = fd_parent[WRITABLE_FD];
	self->read_filehandle = fdopen(self->read_handle, "r");
	self->is_running = TRUE;
	return self->pid; /* Return successfully */
	
      } /* switch */

      (void)close(fd_child[READABLE_FD]);
      (void)close(fd_child[WRITABLE_FD]);
    }
    (void)close(fd_parent[READABLE_FD]);
    (void)close(fd_parent[WRITABLE_FD]);
  }
  return SYS_ERROR;
#undef READABLE_FD
#undef WRITABLE_FD
}

/*************************************************************************
 * ReadLine
 */
static int ReadLine(struct Resolver *self, char *pBuffer, int bufferSize)
{
  int rc = SYS_ERROR;
  
  assert(pBuffer != NULL);
  
  if (self->read_filehandle) {
    if (fgets(pBuffer, bufferSize, self->read_filehandle)) {
      strtok(pBuffer, "\r\n");
      rc = 0;
    }
  }
  return rc;
}

/*************************************************************************
 * FindRequest
 */
static struct ResolverRequest *FindRequest(struct Resolver *self,
					   char *name)
{
  struct ResolverRequest *request;

  for (request = LIST_FIRST(struct ResolverRequest, link, self->first);
       request;
       request = LIST_NEXT(struct ResolverRequest, link, request))
    {
      if (strequal(request->name, name))
	return request;
    }
  return NULL;
}

/*************************************************************************
 * FreeRequest
 */
static void FreeRequest(struct Resolver *self,
			struct ResolverRequest *request)
{
  if ((self) && (request)) {
    LIST_REMOVE(struct ResolverRequest, link, self->first, request);
    free(request);
  }
}

/*************************************************************************
 * ReadRequest
 */
static struct ResolverRequest *ReadRequest(struct Resolver *self)
{
  int stop = FALSE;
  int res_error = 0;
  struct ResolverRequest *request = NULL;
  struct addrinfo *address = NULL;
  struct addrinfo *previous = NULL;
  struct addrinfo *first = NULL;
  char hostname[MAX_HOSTNAME];
  char name[MAX_HOSTNAME];
  char buffer[MAX_BUFFER];

  if (! self->is_running) {
    (void)close(self->read_handle);
    self->read_handle = SYS_ERROR;
    (void)close(self->write_handle);
    self->write_handle = SYS_ERROR;
    errno = ECHILD;
    return NULL;
  }
  
  while ((! stop) &&
	 (ReadLine(self, buffer, sizeof(buffer)) != SYS_ERROR))
    {
      switch (buffer[0]) {
      case 'Z':
	first = NULL;
	/* structure will be populated later */
	break;
	  
      case 'N':
	if (1 < sscanf(&buffer[2], "%s", hostname)) {
	  hostname[0] = (char)0;
	}
	break;

      case 'A':
	{
	  int family, port;

	  previous = address;
	  address = (struct addrinfo *)calloc(1, sizeof(struct addrinfo));
	  if (first == NULL)
	    first = address;
	  
	  if (address) {
	    if (3 == sscanf(&buffer[2], "%d %d %s", &family, &port, name)) {
	      struct sockaddr_in *sain;
	    
	      address->ai_family = family;
	      address->ai_protocol = SOCK_STREAM;
	      address->ai_socktype = SOCK_STREAM;
	      address->ai_addrlen = sizeof(struct sockaddr_in);
	      sain = (struct sockaddr_in *)calloc(1, address->ai_addrlen);
	      address->ai_addr = (struct sockaddr *)sain;
	      if (sain) {
		sain->sin_family = family;
		sain->sin_addr.s_addr = inet_addr(name);
		sain->sin_port = htons(port);
		if (previous)
		  previous->ai_next = address;
	      }
	    }
	  }
	  break;
	}

      case 'E': /* Error */
	(void)sscanf(&buffer[2], "%d", &res_error);
	stop = TRUE;
	break;

      case 'X':
	if (first) {
	  first->ai_canonname = strdup(hostname);
	  if (1 == sscanf(&buffer[2], "%s", name)) {
	    request = FindRequest(self, name);
	    request->address = first;
	    res_error = 0;
	    stop = TRUE;
	  }
	}
	break;

      default:
	stop = TRUE;
	break;
      
      } /* switch */
    } /* while */
  
  return request;
}

/*************************************************************************
 * GetRequest
 */
static struct ResolverRequest *GetRequest(struct Resolver *self,
					  char *name)
{
  struct ResolverRequest *request;

  request = FindRequest(self, name);
  if ((request) && (request->address == NULL)) {
    request = ReadRequest(self);
  }
  return request;
}

/*************************************************************************
 * Query
 */
static int Query(char *name, unsigned int flags)
{
  int status = RESOLVER_ERROR;
  int family;
  char buffer[MAX_BUFFER];
  struct Resolver *resolver;
  struct ResolverRequest *request = NULL;
  
  resolver = GlobalGetResolver();
  assert(resolver != NULL);

  /* Start resolver child process if it is inactive */
  if (! resolver->is_running) {
    (void)Launch(resolver);
  }
  
  if (resolver->is_running) {
    request = (struct ResolverRequest *)calloc(1, sizeof (struct ResolverRequest));
    if (request) {
      request->name = strdup(name);
      LIST_APPEND(struct ResolverRequest, link, resolver->first, request);
      /* Send lookup request to resolver child */
      sprintf(buffer, "L %s 0 %d\n",
	      name, AF_INET);
      write(resolver->write_handle, buffer, strlen(buffer));
      status = RESOLVER_WORKING;
    }
  }
  return status;
}

/*************************************************************************
 * Retrieve
 */
static int Retrieve(char *name,
		    unsigned int flags,
		    struct addrinfo **result)
{
  int status = RESOLVER_ERROR;
  struct addrinfo *address = NULL;
  struct ResolverRequest *request;

  if (flags & RESOLVER_CANCEL) {
    /* We mark that the lookup must be discarded */
  } else {
    request = GetRequest(GlobalGetResolver(), name);
    if (request == NULL) {
      status = RESOLVER_ERROR;
    } else {
      /* Store result and free request */
      *result = request->address;
      FreeRequest(GlobalGetResolver(), request);
      status = RESOLVER_OK;
    }
  }
  
  return status;
}


/*************************************************************************
 *
 * Public functions
 *
 ************************************************************************/
									  
/*************************************************************************
 * ResolverHandle
 */
int ResolverHandle(void)
{
  struct Resolver *resolver;
  
  resolver = GlobalGetResolver();
  assert(resolver != NULL);

  if (resolver->is_running)
    return resolver->read_handle;

  return SYS_ERROR;
}

/*************************************************************************
 * ResolverPid
 *
 * Must be async-safe.
 */
pid_t ResolverPid(void)
{
  struct Resolver *resolver;
  
  resolver = GlobalGetResolver();
  assert(resolver != NULL);

  if (resolver->is_running)
    return resolver->pid;

  return (pid_t)SYS_ERROR;
}

/*************************************************************************
 * ResolverTerminated
 *
 * Must be async-safe.
 */
void ResolverTerminated(void)
{
  struct Resolver *resolver;

  resolver = GlobalGetResolver();
  assert(resolver != NULL);
  resolver->is_running = FALSE;
}

/*************************************************************************
 * ResolverLookup
 */
int ResolverLookup(char *name,
		   unsigned int flags,
		   struct addrinfo **result)
{
  int status = RESOLVER_WORKING;

  errno = 0;
  
  if ((name == NULL) || (result == NULL)) {
    errno = EINVAL;
    return RESOLVER_ERROR;
  }
  
  /* Examine if we already have queued 'name' */
  
  if (FindRequest(GlobalGetResolver(), name) == NULL) {
    status = Query(name, flags);
  } else if (! (flags & RESOLVER_QUEUE)) {
    flags |= RESOLVER_BLOCK;
  } else {
    status = RESOLVER_ERROR;
  }
  *result = NULL;
  
  if ((flags & RESOLVER_BLOCK) && (status != RESOLVER_ERROR)) {
    status = Retrieve(name, flags, result);
  }
  
  return status;
}

/*************************************************************************
 * ResolverFree
 */
void ResolverFree(struct addrinfo *address)
{
  struct addrinfo *next;
  
  while (address) {
    next = address->ai_next;
    if (address->ai_canonname)
      free(address->ai_canonname);
    free(address);
    address = next;
  }
}

/*************************************************************************
 * ResolverInit
 */
void ResolverInit(unsigned int flags)
{
  struct sigaction sact;
  struct Resolver *resolver;

  if (! (flags & RESOLVER_INIT_WITHOUT_SIGNALHANDLER)) {
    /* Install SIGCHLD signal handler */
    memset(&sact, 0, sizeof(sact));
    sigemptyset(&sact.sa_mask);
    sact.sa_flags = SA_NOCLDSTOP;
    sact.sa_handler = ChildHandler;
    (void)sigaction(SIGCHLD, &sact, NULL);
  }

  /* Initialize resolver structure */
  resolver = GlobalGetResolver();
  assert(resolver != NULL);
  resolver->is_running = FALSE;
  resolver->pid = SYS_ERROR;
  resolver->read_handle = SYS_ERROR;
  resolver->write_handle = SYS_ERROR;
  resolver->read_filehandle = NULL;
}

/*************************************************************************
 * ResolverFini
 */
void ResolverFini(void)
{
  struct Resolver *resolver;
  struct ResolverRequest *iterator;
  struct ResolverRequest *iteratorNext;

  /* Terminate the resolver child */
  resolver = GlobalGetResolver();
  if (resolver->is_running && (SYS_ERROR != resolver->pid)) {
    (void)kill(resolver->pid, SIGTERM);
  }
  if (resolver->read_filehandle) {
    (void)fclose(resolver->read_filehandle);
  }

  /* Remove all resolve requests */
  iterator = LIST_FIRST(struct ResolverRequest, link, resolver->first);
  while (iterator) {
    iteratorNext = LIST_NEXT(struct ResolverRequest, link, iterator);
    LIST_REMOVE(struct ResolverRequest, link, resolver->first, iterator);
    free(iterator);
    iterator = iteratorNext;
  }
  resolver->first = NULL;
}
