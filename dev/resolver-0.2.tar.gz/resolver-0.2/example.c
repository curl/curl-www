#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "resolver.h"

int main(int argc, char *argv[])
{
  struct addrinfo *address;
  struct addrinfo *iterator;
  char *hostname;
  int i;
  int status = 0;
  
  if (argc <= 1) {
    fprintf(stderr, "Usage: %s <host> [<host>...]\n", argv[0]);
    exit(1);
  }

  ResolverInit(RESOLVER_INIT_DEFAULT);
  i = 1;
  while (i < argc) {
    hostname = argv[i];
    status = ResolverLookup(hostname, 0, &address);
    switch (status) {
    case RESOLVER_WORKING:
      printf("Processing\n");
      sleep(1);
      continue; /* while */
      
    case RESOLVER_OK:
      for (iterator = address; iterator; iterator = iterator->ai_next) {
	printf("%s: %s\n", address->ai_canonname,
	       inet_ntoa(((struct sockaddr_in *)iterator->ai_addr)->sin_addr));
      }
      ResolverFree(address);
      break;
      
    case RESOLVER_ERROR:
    default:
      fprintf(stderr, "ResolverLookup (%s): %s\n",
	      argv[i], strerror(errno));
      break;
    }
    i++;
  }
  ResolverFini();
  return status;
}
