#
# $Id: form.pm,v 1.1 2003/04/22 12:45:27 crisb Exp $
#

package WWW::Curl::form;
use strict;

require WWW::Curl;

#use vars qw(@ISA @EXPORT_OK);
#require Exporter;
#require AutoLoader;
# @ISA = qw(Exporter DynaLoader);

1;
