/***************************************************************************
 *                                  _   _ ____  _
 *  Project                     ___| | | |  _ \| |
 *                             / __| | | | |_) | |
 *                            | (__| |_| |  _ <| |___
 *                             \___|\___/|_| \_\_____|
 *
 * Copyright (C) 1998 - 2004, Daniel Stenberg, <daniel@haxx.se>, et al.
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution. The terms
 * are also available at http://curl.haxx.se/docs/copyright.html.
 *
 * You may opt to use, copy, modify, merge, publish, distribute and/or sell
 * copies of the Software, and permit persons to whom the Software is
 * furnished to do so, under the terms of the COPYING file.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 * $Id: CURL.java,v 0.1 2004/10/21 12:21PM 
 ***************************************************************************/
package org.curl;


/**
 * Class <code>CURL</code><br>
 * <p>This class defines the main libcurl option constants found in
 * curl.h. Options are passed to libcurl via the jni wrapper
 * to create curl objects.<br></p>
 * 
 * <p><b>TODO:</b> Need to implement some of the other constants such
 * as CURLExxx for error checking and implement a throwable error
 * interface. When the error interface is implemented we'll have to
 * instantiate the class.</p>
 */
public class CURL {
	// **************************************************
	// ***** CURL OPTIONS *****
	/**
	 * This is the FILE * or void * the regular output should 
	 * be written to.
	 * (value is 10001) 
	 */
	public static final int OPT_FILE = 10001;

	/**
	 * <p>The full URL to get/put. If the given URL lacks the protocol 
	 * part ("http://" or "ftp://" etc), it will attempt to guess 
	 * which protocol to use based on the given host name.</p>
	 * <p>NOTE: <code>OPT_URL</code> is the only option that must be set 
	 * before <code>jni_perform(int)</code>.</p><br>
	 * (value is 10002)
	 * @see CurlGlue#setopt(int, int, String) setopt
	 * @see CurlGlue#perform(int) perform
	 */
	public static final int OPT_URL = 10002;

	/**
	 * Set the remote port number to connect to, instead of the one 
	 * specified in the URL or the default port for the used protocol.<br>
	 * (value is 3)
	 * @see CurlGlue#setopt(int, int, int) setopt 
	 */
	public static final int OPT_PORT = 3;

	/** 
	 * <p>Name of proxy to use. To specify port number in this string, 
	 * append :[port] to the end of the host name. The proxy string 
	 * may be prefixed with [protocol]:// since any such prefix will 
	 * be ignored. The proxy's port number may optionally be specified 
	 * with the separate option <code>OPT_PROXYPORT</code>.</p><br>
	 * <p><b>NOTE:</b> when you tell the library to use an HTTP proxy, libcurl 
	 * will transparently convert operations to HTTP even if you specify 
	 * an FTP URL etc. This may have an impact on what other features of 
	 * the library you can use, such as <code>OPT_QUOTE</code> and similar FTP 
	 * specifics that don't work unless you tunnel through the HTTP proxy. 
	 * Such tunneling is activated with <code>OPT_HTTPPROXYTUNNEL</code>.</p><br>
	 * (value is 10004)
	 * @see #OPT_PROXYPORT OPT_PROXYPORT
	 * @see #OPT_QUOTE OPT_QUOTE
	 * @see #OPT_HTTPPROXYTUNNEL HTTPPROXYTUNNEL
	 * @see CurlGlue#jni_setopt(int, int, String)
	 */
	public static final int OPT_PROXY = 10004;

	/** 
	 * "name:password" to use when fetching. 
	 * (value is 10005)
	 */
	public static final int OPT_USERPWD = 10005;

	/**
	 * "name:password" to use with proxy. 
	 * (value is 10006)
	 */
	public static final int OPT_PROXYUSERPWD = 10006;

	/**
	 * Range to get, specified as an ASCII string.
	 * (value is 10007)
	 */
	public static final int OPT_RANGE = 10007;

	/**
	 * Specified file stream to upload from (use as input)<br>
	 * (value is 10009)
	 */
	public static final int OPT_INFILE = 10009;

	/**
	 * Pass a buffer to libcurl to store more readable error messages in. 
	 * Currently not implemented.<br>
	 * (value is 10010) 
	 * @see #OPT_VERBOSE OPT_VERBOSE
	 */
	public static final int OPT_ERRORBUFFER = 10010;

	/**
	 * Used to set a callback function to handle the data returned by libcurl.
	 * An instance of the <code>CurlWrite</code> interface is required to 
	 * set this option. Data chunks returned by libcurl are in the
	 * form of a byte[] array.<br>
	 * (value is 20011)
	 * @see CurlWrite CurlWrite
	 * @see #setopt(int, int, CurlWrite) setopt
	 */
	public static final int OPT_WRITEFUNCTION = 20011;

	/**
	 *  Function that will be called to read the input (instead of fread). The
	 * parameters will use fread() syntax, make sure to follow them. Not implemented.
	 * (value is 20012) 
	 */
	public static final int OPT_READFUNCTION = 20012;

	/** 
	 * Time-out the read operation after this amount of seconds
	 * (value is 13) 
	 */
	public static final int OPT_TIMEOUT = 13;

	/** If the public static final int OPT_INFILE is used, this can be used to inform libcurl about
	 * how large the file being sent really is. That allows better error
	 * checking and better verifies that the upload was succcessful. -1 means
	 * unknown size.
	 *
	 * For large file support, there is also a _LARGE version of the key
	 * which takes an off_t type, allowing platforms with larger off_t
	 * sizes to handle larger files.  See below for INFILESIZE_LARGE.
	 * (value is 14)
	 */
	public static final int OPT_INFILESIZE = 14;

	/**
	 * POST input fields.
	 * (value is 10015) 
	 */
	public static final int OPT_POSTFIELDS = 10015;

	/** 
	 * Set the referer page (needed by some CGIs)
	 * (value is 10016)
	 */
	public static final int OPT_REFERER = 10016;

	/**
	 * Set the FTP PORT string (interface name, named or numerical IP address)
	 * Use i.e '-' to use default address.
	 * (value is 10017) 
	 */
	public static final int OPT_FTPPORT = 10017;

	/**
	 * Set the User-Agent string (examined by some CGIs)
	 * (value is 10018) 
	 */
	public static final int OPT_USERAGENT = 10018;

	/**
	 * If the download receives less than "low speed limit" bytes/second
	 * during "low speed time" seconds, the operations is aborted.
	 * You could i.e if you have a pretty high speed connection, abort if
	 * it is less than 2000 bytes/sec during 20 seconds.
	 * Set the "low speed limit"
	 * (value is 19) 
	 */
	public static final int OPT_LOW_SPEED_LIMIT = 19;

	/**
	 *  Set the "low speed time"
	 * (value is 20) 
	 */
	public static final int OPT_LOW_SPEED_TIME = 20;

	/** 
	 * Set the continuation offset.
	 * Note there is also a _LARGE version of this key which uses
	 * off_t types, allowing for large file offsets on platforms which
	 * use larger-than-32-bit off_t's.  Look below for RESUME_FROM_LARGE.
	 * (value is 21)
	 */
	public static final int OPT_RESUME_FROM = 21;

	/**
	 * Set cookie in request:
	 * (value is 10022) 
	 */
	public static final int OPT_COOKIE = 10022;

	/**
	 * This points to a linked list of headers, struct curl_slist kind
	 * (value is 10023) 
	 */
	public static final int OPT_HTTPHEADER = 10023;

	/**
	 * This points to a linked list of post entries, struct HttpPost
	 * (value is 10024) 
	 */
	public static final int OPT_HTTPPOST = 10024;

	/**
	 * name of the file keeping your private SSL-certificate
	 * (value is 10025)
	 */
	public static final int OPT_SSLCERT = 10025;

	/**
	 * password for the SSL-private key, keep this for compatibility
	 * (value is 10026) 
	 */
	public static final int OPT_SSLCERTPASSWD = 10026;

	/**
	 * password for the SSL private key
	 * (value is 10026) 
	 */
	public static final int OPT_SSLKEYPASSWD = 10026;

	/**
	 * send TYPE parameter?
	 * (value is 27) 
	 */
	public static final int OPT_CRLF = 27;

	/**
	 * send linked-list of QUOTE commands 
	 * (value is 10028)
	 */
	public static final int OPT_QUOTE = 10028;

	/**
	 * send FILE * or void * to store headers to, if you use a callback it
	 * is simply passed to the callback unmodified
	 * (value is 10029) 
	 */
	public static final int OPT_WRITEHEADER = 10029;

	/**
	 * point to a file to read the initial cookies from, also enables
	 * "cookie awareness"
	 * (value is 10031) 
	 */
	public static final int OPT_COOKIEFILE = 10031;

	/**
	 * What version to specifly try to use.
	 * See CURL_SSLVERSION defines below.
	 * (value is 32) 
	 */
	public static final int OPT_SSLVERSION = 32;

	/**
	 * What kind of HTTP time condition to use, see defines
	 * (value is 33) 
	 */
	public static final int OPT_TIMECONDITION = 33;

	/**
	 * Time to use with the above condition. Specified in number of seconds
	 * since 1 Jan 1970<br>
	 * (value is 24) 
	 */
	public static final int OPT_TIMEVALUE = 34;

	/* 35  = OBSOLETE */

	/**
	 * Custom request, for customizing the get command like
	 * <li>HTTP: DELETE, TRACE and others</li>
	 * <li>FTP: to use a different list command</li><br>
	 * (value is 10036)
	 */
	public static final int OPT_CUSTOMREQUEST = 10036;

	/**
	 * Set an optional stream instead of stderr when showing the 
	 * progress meter and displaying <code>OPT_VERBOSE</code> data.
	 * Currently not implemented.<br>
	 * (value is 10037) 
	 * @see #OPT_VERBOSE OPT_VERBOSE
	 */
	public static final int OPT_STDERR = 10037;

	/* 38 is not used */

	/**
	 * send linked-list of post-transfer QUOTE commands
	 * (value is 10039) 
	 */
	public static final int OPT_POSTQUOTE = 10039;

	/**
	 * Pass a pointer to string of the output using full variable-replacement
	 * as described elsewhere.
	 * (value is 10040) 
	 */
	public static final int OPT_WRITEINFO = 10040;

	/**
	 * Set the parameter to non-zero to get the library to display a lot of
	 * verbose information about its operations. Very useful for libcurl and/or
	 * protocol debugging and understanding. The verbose information will be
	 * sent to stderr. <br>
	 * (value is 41)
	 * @see #OPT_STDERR OPT_STDERR
	 * @see #setopt(int, int, int) setopt 
	 */
	public static final int OPT_VERBOSE = 41;

	/**
	 * A non-zero parameter tells the library to include the 
	 * header in the body output. This is only relevant for protocols 
	 * that actually have headers preceding the data (like HTTP).<br>
	 * (value is 42)
	 * 
	 * @see #setopt(int, int, int) setopt 
	 */
	public static final int OPT_HEADER = 42;

	/**
	 * A non-zero parameter tells the library to shut off the built-in 
	 * progress meter completely.<br>
	 * (value is 43) 
	 *  
	 * <p><b>NOTE:</b> future versions of libcurl is likely to not have any 
	 * built-in progress meter at all.</p> 
	 * @see #setopt(int, int, int) setopt 
	 */
	public static final int OPT_NOPROGRESS = 43;

	/**
	 * use HEAD to get http document
	 * (value is 44)<br>
	 */
	public static final int OPT_NOBODY = 44;

	/**
	 * A non-zero (1) parameter tells the library to fail silently if 
	 * the HTTP code returned is equal to or larger than 300. 
	 * The default action would be to return the page normally, 
	 * ignoring that code.<br>
	 * (value is 45)
	 * @see CurlGlue#setopt(int, int, int) setopt 
	 */
	public static final int OPT_FAILONERROR = 45;

	/**
	 * this is an upload
	 * (value is 46) 
	 */
	public static final int OPT_UPLOAD = 46;

	/**
	 * HTTP POST method
	 * (value is 47) 
	 */
	public static final int OPT_POST = 47;

	/**
	 * Use NLST when listing ftp dir
	 * (value is 48) 
	 */
	public static final int OPT_FTPLISTONLY = 48;

	/**
	 * Append instead of overwrite on upload!
	 * (value is 50)
	 */
	public static final int OPT_FTPAPPEND = 50;

	/**
	 * Specify whether to read the user+password from the .netrc or the URL.
	 * This must be one of the CURL_NETRC_* enums below.
	 * (value is 51)
	 */
	public static final int OPT_NETRC = 51;

	/**
	 * use Location: Luke!  ==>> ???? 8^)
	 * (value is 52)
	 */
	public static final int OPT_FOLLOWLOCATION = 52;

	/**
	 * transfer data in text/ASCII format
	 * (value is 53)
	 */
	public static final int OPT_TRANSFERTEXT = 53;

	/**
	 * HTTP PUT
	 * (value is 54)
	 */
	public static final int OPT_PUT = 54;

	/* 55  = OBSOLETE */

	/**
	 * Set a function that gets called by libcurl instead of its internal 
	 * equivalent with a frequent interval during data transfer.
	 * Also note that <code>OPT_NOPROGRESS</code> must be set to FALSE(0) to make 
	 * this function actually get called
	 * Currently not implemented. 
	 * (value is 20056)
	 * @see #OPT_NOPROGRESS OPT_NOPROGRESS
	 */
	public static final int OPT_PROGRESSFUNCTION = 20056;

	/**
	 * Pass data that will be untouched by libcurl and passed 
	 * as the first argument in the progress callback set with 
	 * <code>OPT_PROGRESSFUNCTION</code>.
	 * Currently not implemented.<br>
	 * (value is 10057) 
	 * @see #CURLOPT_PROGRESSFUNCTION
	 *
	 */
	public static final int OPT_PROGRESSDATA = 10057;

	/**
	 * We want the referer field set automatically when following locations
	 * (value is 58) 
	 */
	public static final int OPT_AUTOREFERER = 58;

	/**
	 * Pass a long with this option to set the proxy port to connect to 
	 * unless it is specified in the proxy string <code>OPT_PROXY</code><br>
	 * (value is 59)
	 * @see #OPT_PROXY
	 * @see CurlGlue#setopt(int, int, int) setopt 
	 */
	public static final int OPT_PROXYPORT = 59;

	/**
	 * size of the POST input data, if strlen() is not good to use
	 * (value is 60) 
	 */
	public static final int OPT_POSTFIELDSIZE = 60;

	/**
	 * Set the parameter to non-zero to get the library to tunnel all 
	 * operations through a given HTTP proxy. Note that there is a big 
	 * difference between using a proxy and to tunnel through it. 
	 * If you don't know what this means, you probably don't want this 
	 * tunneling option.<br>
	 * (value is 61)
	 * @see #OPT_PROXY
	 * @see CurlGlue#setopt(int, int, int) setopt 
	 */
	public static final int OPT_HTTPPROXYTUNNEL = 61;

	/**
	 * This set the interface name to use as an outgoing network 
	 * interface. The name can be an interface name, an IP address 
	 * or a host name.<br>
	 * (value is 10062)
	 * @see CurlGlue#jni_setopt(int, int, String)
	 */
	public static final int OPT_INTERFACE = 10062;

	/**
	 * Set the krb4 security level, this also enables krb4 awareness.  This is a
	 * string, 'clear', 'safe', 'confidential' or 'private'.  If the string is
	 * set but doesn't match one of these, 'private' will be used.
	 * (value is 10063)
	 */
	public static final int OPT_KRB4LEVEL = 10063;

	/**
	 * Set if we should verify the peer in ssl handshake, set 1 to verify.
	 * (value is 64) 
	 */
	public static final int OPT_SSL_VERIFYPEER = 64;

	/**
	 * The CApath or CAfile used to validate the peer certificate
	 * this option is used only if SSL_VERIFYPEER is true 
	 * (value is 10065)
	 */
	public static final int OPT_CAINFO = 10065;

	/* 66  = OBSOLETE */
	/* 67  = OBSOLETE */

	/**
	 * Maximum number of http redirects to follow
	 * (value is 68) 
	 */
	public static final int OPT_MAXREDIRS = 68;

	/**
	 * Pass a long set to 1 to get the date of the requested document (if
	 * possible)! Pass a zero to shut it off.
	 * (value is 69) 
	 */
	public static final int OPT_FILETIME = 69;

	/**
	 * This points to a linked list of telnet options
	 * (value is 10070) 
	 */
	public static final int OPT_TELNETOPTIONS = 10070;

	/**
	 * Max amount of cached alive connections
	 * (value is 71) 
	 */
	public static final int OPT_MAXCONNECTS = 71;

	/**
	 * What policy to use when closing connections when the cache is filled up
	 * (value is 72) 
	 */
	public static final int OPT_CLOSEPOLICY = 72;

	/* 73  = OBSOLETE */

	/**
	 * Set to explicitly use a new connection for the upcoming transfer.
	 * Do not use this unless you're absolutely sure of this, as it makes the
	 * operation slower and is less friendly for the network.
	 * (value is 74) 
	 */
	public static final int OPT_FRESH_CONNECT = 74;

	/**
	 * Set to explicitly forbid the upcoming transfer's connection to be re-used
	 * when done. Do not use this unless you're absolutely sure of this, as it
	 * makes the operation slower and is less friendly for the network.
	 * (value is 75)
	 */
	public static final int OPT_FORBID_REUSE = 75;

	/**
	 * Set to a file name that contains random data for libcurl to use to
	 * seed the random engine when doing SSL connects. 
	 * (value is 10076)
	 */
	public static final int OPT_RANDOM_FILE = 10076;

	/**
	 * Set to the Entropy Gathering Daemon socket pathname
	 * (value is 10077) 
	 */
	public static final int OPT_EGDSOCKET = 10077;

	/**
	 * Time-out connect operations after this amount of seconds, if connects
	 * are OK within this time, then fine... This only aborts the connect
	 * phase. [Only works on unix-style/SIGALRM operating systems]<br>
	 * (value is 78) 
	 */
	public static final int OPT_CONNECTTIMEOUT = 78;

	/**
	 * Set a function that gets called by libcurl as soon as there 
	 * is received header data that needs to be written down. 
	 * The headers are guaranteed to be written one-by-one and 
	 * only complete lines are written.
	 * Currently not implemented.<br>
	 * (value is 20079) 
	 */
	public static final int OPT_HEADERFUNCTION = 20079;

	/**
	 * Set this to force the HTTP request to get back to GET. Only really usable
	 * if POST, PUT or a custom request have been used first.<br>
	 * (value is 80)(Coincidence??? I think NOT!)
	 */
	public static final int OPT_HTTPGET = 80;

	/**
	 * Set if we should verify the Common name from the peer certificate in ssl
	 * handshake, set 1 to check existence, 2 to ensure that it matches the
	 * provided hostname.
	 * (value is 81) 
	 */
	public static final int OPT_SSL_VERIFYHOST = 81;

	/**
	 * Specify which file name to write all known cookies in after completed
	 * operation. Set file name to "-" (dash) to make it go to stdout.
	 * (value is 10082) 
	 */
	public static final int OPT_COOKIEJAR = 10082;

	/**
	 * Specify which SSL ciphers to use
	 * (value is 10083) 
	 */
	public static final int OPT_SSL_CIPHER_LIST = 10083;

	/**
	 * Specify which HTTP version to use! This must be set to one of the
	 * CURL_HTTP_VERSION* enums set below.
	 * (value is 84) 
	 */
	public static final int OPT_HTTP_VERSION = 84;

	/**
	 * Specificly switch on or off the FTP engine's use of the EPSV command. By
	 * default, that one will always be attempted before the more traditional
	 * PASV command.
	 * (value is 85) 
	 */
	public static final int OPT_FTP_USE_EPSV = 85;

	/**
	 * type of the file keeping your SSL-certificate ("DER", "PEM", "ENG")
	 * (value is 10086) 
	 */
	public static final int OPT_SSLCERTTYPE = 10086;

	/**
	 * name of the file keeping your private SSL-key
	 * (value is 10087) 
	 */
	public static final int OPT_SSLKEY = 10087;

	/** 
	 * type of the file keeping your private SSL-key ("DER", "PEM", "ENG")
	 * (value is 10088) 
	 */
	public static final int OPT_SSLKEYTYPE = 10088;

	/**
	 * crypto engine for the SSL-sub system
	 * (value is 10089) 
	 */
	public static final int OPT_SSLENGINE = 10089;

	/**
	 * set the crypto engine for the SSL-sub system as default
	 * the param has no meaning...<br>
	 * (value is 90)
	 */
	public static final int OPT_SSLENGINE_DEFAULT = 90;

	/**
	 * Obsolete.<br>
	 * (value is 91)
	 * @deprecated This option is obsolete. 
	 * Use {@link #OPT_SHARE OPT_SHARE} instead
	 * @see #OPT_SHARE
	 */
	public static final int OPT_DNS_USE_GLOBAL_CACHE = 91;

	/**
	 * Sets the timeout in seconds. Name resolves will be kept in memory 
	 * for this number of seconds. Set to zero (0) to completely disable 
	 * caching, or set to -1 to make the cached entries remain forever. 
	 * By default, libcurl caches this info for 60 seconds.<br>
	 * (value is 92)
	 * @see CurlGlue#setopt(int, int, int) setopt 
	 */
	public static final int OPT_DNS_CACHE_TIMEOUT = 92;

	/**
	 * send linked-list of pre-transfer QUOTE commands (Wesley Laxton)
	 * (value is 93)
	 */
	public static final int OPT_PREQUOTE = 93;

	/**
	 * set the debug function callback
	 * (value is 20094) 
	 */
	public static final int OPT_DEBUGFUNCTION = 20094;

	/**
	 * set the data for the debug function
	 * (value is 10095) 
	 */
	public static final int OPT_DEBUGDATA = 10095;

	/**
	 * mark this as start of a cookie session
	 * (value is 96) 
	 */
	public static final int OPT_COOKIESESSION = 96;

	/**
	 * The CApath directory used to validate the peer certificate
	 * this option is used only if SSL_VERIFYPEER is true
	 * (value is 10097) 
	 */
	public static final int OPT_CAPATH = 10097;

	/**
	 * Sets the preferred size for the receive buffer in libcurl. The 
	 * main point of this would be that the write callback gets called 
	 * more often and with smaller chunks. This is just treated as a 
	 * request, not an order. You cannot be guaranteed to actually get 
	 * the given size.<br>
	 * (value is 98) 
	 * @see CurlGlue#setopt(int, int, int) setopt 
	 */
	public static final int OPT_BUFFERSIZE = 98;

	/**
	 * Instruct libcurl to not use any signal/alarm handlers, even when using
	 * timeouts. This option is useful for multi-threaded applications.
	 * See libcurl-the-guide for more background information.
	 * (value is 99) 
	 */
	public static final int OPT_NOSIGNAL = 99;

	/**
	 * Provide a CURLShare for mutexing non-ts data
	 * (value is 10100) 
	 */
	public static final int OPT_SHARE = 10100;

	/**
	 * Indicates type of proxy. accepted values are CURLPROXY_HTTP (default;
	 * CURLPROXY_SOCKS4 and CURLPROXY_SOCKS5. Currently not implemented.<br>
	 * (value is 101)
	 * @see #OPT_PROXY
	 * @see #OPT_PROXYPORT
	 */
	public static final int OPT_PROXYTYPE = 101;

	/**
	 * Set the Accept-Encoding string. Use this to tell a server you would like
	 * the response to be compressed.
	 * (value is 10102) 
	 */
	public static final int OPT_ENCODING = 10102;

	/**
	 * Set pointer to private data
	 * (value is 10103) 
	 */
	public static final int OPT_PRIVATE = 10103;

	/**
	 * Set aliases for HTTP 200 in the HTTP Response header
	 * (value is 10104) 
	 */
	public static final int OPT_HTTP200ALIASES = 10104;

	/**
	 * Continue to send authentication (user+password) when following locations,
	 * even when hostname changed. This can potentionally send off the name
	 * and password to whatever host the server decides.
	 * (value is 105) 
	 */
	public static final int OPT_UNRESTRICTED_AUTH = 105;

	/**
	 * Specificly switch on or off the FTP engine's use of the EPRT command ( it
	 * also disables the LPRT attempt). By default, those ones will always be
	 * attempted before the good old traditional PORT command.
	 * (value is 106) 
	 */
	public static final int OPT_FTP_USE_EPRT = 106;

	/**
	 * Set this to a bitmask value to enable the particular authentications
	 * methods you like. Use this in combination with public static final int OPT_USERPWD.
	 * Note that setting multiple bits may cause extra network round-trips.
	 * (value is 107) 
	 */
	public static final int OPT_HTTPAUTH = 107;

	/**
	 * Set the ssl context callback function, currently only for OpenSSL ssl_ctx
	 * in second argument. The function must be matching the
	 * curl_ssl_ctx_callback proto.
	 * (value is 20108) 
	 */
	public static final int OPT_SSL_CTX_FUNCTION = 20108;

	/**
	 * Set the userdata for the ssl context callback function's third
	 * argument
	 * (value is 10109) 
	 */
	public static final int OPT_SSL_CTX_DATA = 10109;

	/**
	 * FTP Option that causes missing dirs to be created on the remote server
	 * (value is 110) 
	 */
	public static final int OPT_FTP_CREATE_MISSING_DIRS = 110;

	/**
	 * Set this to a bitmask value to enable the particular authentications
	 * methods you like. Use this in combination with public static final int OPT_PROXYUSERPWD.
	 * Note that setting multiple bits may cause extra network round-trips.
	 * (value is 111) 
	 */
	public static final int OPT_PROXYAUTH = 111;

	/**
	 * FTP option that changes the timeout, in seconds, associated with
	 * getting a response.  This is different from transfer timeout time and
	 * essentially places a demand on the FTP server to acknowledge commands
	 * in a timely manner.
	 * (value is 112) 
	 */
	public static final int OPT_FTP_RESPONSE_TIMEOUT = 112;

	/**
	 * Set this option to one of the CURL_IPRESOLVE_* defines (see below) to
	 * tell libcurl to resolve names to those IP versions only. This only has
	 * affect on systems with support for more than one, i.e IPv4 _and_ IPv6.
	 * (value is 113) 
	 */
	public static final int OPT_IPRESOLVE = 113;

	/**
	 * Set this option to limit the size of a file that will be downloaded from
	 * an HTTP or FTP server.
	 * Note there is also _LARGE version which adds large file support for
	 * platforms which have larger off_t sizes.  See MAXFILESIZE_LARGE below.
	 * (value is 114) 
	 */
	public static final int OPT_MAXFILESIZE = 114;

	/**
	 * See the comment for INFILESIZE above, but in short, specifies
	 * the size of the file being uploaded.  -1 means unknown.
	 * (value is 30115)
	 */
	public static final int OPT_INFILESIZE_LARGE = 30115;

	/**
	 * Sets the continuation offset.  There is also a LONG version of this;
	 * look above for RESUME_FROM.
	 * (value is 30116)
	 */
	public static final int OPT_RESUME_FROM_LARGE = 30116;

	/** 
	 * Sets the maximum size of data that will be downloaded from
	 * an HTTP or FTP server.  See MAXFILESIZE above for the LONG version.
	 * (value is 30117)
	 */
	public static final int OPT_MAXFILESIZE_LARGE = 30117;

	/**
	 * Set this option to the file name of your .netrc file you want libcurl
	 * to parse (using the public static final int OPT_NETRC option). If not set, libcurl will do
	 * a poor attempt to find the user's home directory and check for a .netrc
	 * file in there.
	 * (value is 10118)
	 */
	public static final int OPT_NETRC_FILE = 10118;

	/**
	 * Enable SSL/TLS for FTP, pick one of:
	 * <li>CURLFTPSSL_TRY     - try using SSL, proceed anyway otherwise</li>
	 * <li>CURLFTPSSL_CONTROL - SSL for the control connection or fail</li>
	 * <li>CURLFTPSSL_ALL     - SSL for all communication or fail</li>
	 * (value is 119)
	 */
	public static final int OPT_FTP_SSL = 119;

	/**
	 * The _LARGE version of the standard POSTFIELDSIZE option
	 * (value is 30120) 
	 */
	public static final int OPT_POSTFIELDSIZE_LARGE = 30120;

	/**
	 * <p>Pass a long specifying whether the TCP_NODELAY option should 
	 * be set or cleared (1 = set, 0 = clear). The option is cleared 
	 * by default. This will have no effect after the connection has 
	 * been established.</p>
	 * <p>Setting this option will disable TCP's Nagle algorithm. The 
	 * purpose of this algorithm is to try to minimize the number of small 
	 * packets on the network (where "small packets" means TCP segments 
	 * less than the Maximum Segment Size (MSS) for the network).</p>
	 * <p>Maximizing the amount of data sent per TCP segment is good 
	 * because it amortizes the overhead of the send. However, in some 
	 * cases (most notably telnet or rlogin) small segments may need to 
	 * be sent without delay. This is less efficient than sending larger 
	 * amounts of data at a time, and can contribute to congestion on the 
	 * network if overdone.</p><br> 
	 * (value is 121)
	 * @see CurlGlue#setopt(int, int, int) setopt  
	 */
	public static final int OPT_TCP_NODELAY = 121;

	/**
	 * When doing 3rd party transfer, set the source host name with this
	 * (value is 10122) 
	 */
	public static final int OPT_SOURCE_HOST = 10122;

	/**
	 * When doing 3rd party transfer, set the source user and password with this
	 * (value is 10123) 
	 */
	public static final int OPT_SOURCE_USERPWD = 10123;

	/**
	 * When doing 3rd party transfer, set the source file path with this
	 * (value is 10124) 
	 */
	public static final int OPT_SOURCE_PATH = 10124;

	/**
	 * When doing 3rd party transfer, set the source server's port number
	 * with this
	 * (value is 125) 
	 */
	public static final int OPT_SOURCE_PORT = 125;

	/**
	 * When doing 3rd party transfer, decide which server that should get the
	 * PASV command (and the other gets the PORT).
	 * <li>0 (default) - The target host issues PASV.</li>
	 * <li>1           - The source host issues PASV </li><br>
	 * (value is 126)
	 */
	public static final int OPT_PASV_HOST = 126;

	/**
	 * When doing 3rd party transfer, set the source pre-quote linked list
	 * of commands with this
	 * (value is 10127) 
	 */
	public static final int OPT_SOURCE_PREQUOTE = 10127;

	/**
	 * When doing 3rd party transfer, set the source post-quote linked list
	 * of commands with this
	 * (value is 10128) 
	 */
	public static final int OPT_SOURCE_POSTQUOTE = 10128;
	
	// **************************************************
	// CURL ERRORS - These are temporary to allow class 
	//               and error throwing code to compile
	public static final int ERROR_UNSPECIFIED = 5000;
	public static final int ERROR_BAD_ARGUMENT = 5001;
	public static final int ERROR_NON_FATAL = 5002;
	public static final int ERROR_NO_CALLBACK_INSTANCE = 5003;
	public static final int ERROR_FAILED_LOAD_LIBRARY = 5004;
	public static final int ERROR_SECURITY_MANAGER_VIOLATION = 5005;
	public static final int ERROR_NO_JAVACURL_HANDLE_AVAILABLE = 5006;
	public static final int ERROR_NOT_IMPLEMENTED = 5007;
	public static final int ERROR_NULL_ARGUMENT = 5008;

	// TODO: need to sort these out between fatal/non-fatal
	// most of these return a generic message at this time
	public static final int   CURL_OK = 0,
	  ERROR_UNSUPPORTED_PROTOCOL=1,    /* 1 */
	  ERROR_FAILED_INIT=2,             /* 2 */
	  ERROR_URL_MALFORMAT=3,           /* 3 */
	  ERROR_URL_MALFORMAT_USER=4,      /* 4 (NOT USED) */
	  ERROR_COULDNT_RESOLVE_PROXY=5,   /* 5 */
	  ERROR_COULDNT_RESOLVE_HOST=6,    /* 6 */
	  ERROR_COULDNT_CONNECT=7,         /* 7 */
	  ERROR_FTP_WEIRD_SERVER_REPLY=8,  /* 8 */
	  ERROR_FTP_ACCESS_DENIED=9,       /* 9 */
	  ERROR_FTP_USER_PASSWORD_INCORRECT=10, /* 10 */
	  ERROR_FTP_WEIRD_PASS_REPLY=11,    /* 11 */
	  ERROR_FTP_WEIRD_USER_REPLY=12,    /* 12 */
	  ERROR_FTP_WEIRD_PASV_REPLY=13,    /* 13 */
	  ERROR_FTP_WEIRD_227_FORMAT=14,    /* 14 */
	  ERROR_FTP_CANT_GET_HOST=15,       /* 15 */
	  ERROR_FTP_CANT_RECONNECT=16,      /* 16 */
	  ERROR_FTP_COULDNT_SET_BINARY=17,  /* 17 */
	  ERROR_PARTIAL_FILE=18,            /* 18 */
	  ERROR_FTP_COULDNT_RETR_FILE=19,   /* 19 */
	  ERROR_FTP_WRITE_ERROR=20,         /* 20 */
	  ERROR_FTP_QUOTE_ERROR=21,         /* 21 */
	  ERROR_HTTP_RETURNED_ERROR=22,     /* 22 */
	  ERROR_WRITE_ERROR=23,             /* 23 */
	  ERROR_MALFORMAT_USER=24,          /* 24 - NOT USED */
	  ERROR_FTP_COULDNT_STOR_FILE=25,   /* 25 - failed FTP upload */
	  ERROR_READ_ERROR=26,              /* 26 - could open/read from file */
	  ERROR_OUT_OF_MEMORY=27,           /* 27 */
	  ERROR_OPERATION_TIMEOUTED=28,     /* 28 - the timeout time was reached */
	  ERROR_FTP_COULDNT_SET_ASCII=29,   /* 29 - TYPE A failed */
	  ERROR_FTP_PORT_FAILED=30,         /* 30 - FTP PORT operation failed */
	  ERROR_FTP_COULDNT_USE_REST=31,    /* 31 - the REST command failed */
	  ERROR_FTP_COULDNT_GET_SIZE=32,    /* 32 - the SIZE command failed */
	  ERROR_HTTP_RANGE_ERROR=33,        /* 33 - RANGE "command" didn't work */
	  ERROR_HTTP_POST_ERROR=34,         /* 34 */
	  ERROR_SSL_CONNECT_ERROR=35,       /* 35 - wrong when connecting with SSL */
	  ERROR_BAD_DOWNLOAD_RESUME=36,     /* 36 - couldn't resume download */
	  ERROR_FILE_COULDNT_READ_FILE=37,  /* 37 */
	  ERROR_LDAP_CANNOT_BIND=38,        /* 38 */
	  ERROR_LDAP_SEARCH_FAILED=39,      /* 39 */
	  ERROR_LIBRARY_NOT_FOUND=40,       /* 40 */
	  ERROR_FUNCTION_NOT_FOUND=41,      /* 41 */
	  ERROR_ABORTED_BY_CALLBACK=42,     /* 42 */
	  ERROR_BAD_FUNCTION_ARGUMENT=43,   /* 43 */
	  ERROR_BAD_CALLING_ORDER=44,       /* 44 - NOT USED */
	  ERROR_INTERFACE_FAILED=45,        /* 45 - CURLOPT_INTERFACE failed */
	  ERROR_BAD_PASSWORD_ENTERED=46,    /* 46 - NOT USED */
	  ERROR_TOO_MANY_REDIRECTS=47,     /* 47 - catch endless re-direct loops */
	  ERROR_UNKNOWN_TELNET_OPTION=48,   /* 48 - User specified an unknown option */
	  ERROR_TELNET_OPTION_SYNTAX =49,   /* 49 - Malformed telnet option */
	  ERROR_OBSOLETE=50,	         /* 50 - NOT USED */
	  ERROR_SSL_PEER_CERTIFICATE=51,    /* 51 - peer's certificate wasn't ok */
	  ERROR_GOT_NOTHING=52,             /* 52 - when this is a specific error */
	  ERROR_SSL_ENGINE_NOTFOUND=53,     /* 53 - SSL crypto engine not found */
	  ERROR_SSL_ENGINE_SETFAILED=54,    /* 54 - can not set SSL crypto engine as default */
	  ERROR_SEND_ERROR=55,              /* 55 - failed sending network data */
	  ERROR_RECV_ERROR=56,              /* 56 - failure in receiving network data */
	  ERROR_SHARE_IN_USE=57,            /* 57 - share is in use */
	  ERROR_SSL_CERTPROBLEM=58,         /* 58 - problem with the local certificate */
	  ERROR_SSL_CIPHER=59,              /* 59 - couldn't use specified cipher */
	  ERROR_SSL_CACERT=60,              /* 60 - problem with the CA cert (path?) */
	  ERROR_BAD_CONTENT_ENCODING=61,    /* 61 - Unrecognized transfer encoding */
	  ERROR_LDAP_INVALID_URL=62,        /* 62 - Invalid LDAP URL */
	  ERROR_FILESIZE_EXCEEDED=63,       /* 63 - Maximum file size exceeded */
	  ERROR_FTP_SSL_FAILED=64;          /* 64 - Requested FTP SSL level failed */


	/**
	 * Answers a concise, human readable description of the error code.
	 *
	 * @param code the CURL error code.
	 * @return a description of the error code.
	 *
	 * @see CURL
	 */
	static String findErrorText (int code) {
		switch (code) {
			case ERROR_UNSPECIFIED: 
				return "Unspecified Error";
			case ERROR_BAD_ARGUMENT: 
				return "Illegal cURL option argument";
			case ERROR_NULL_ARGUMENT:
				return "NULL cURL option argument passed";
			case ERROR_NO_CALLBACK_INSTANCE:
				return "cURL callback function has not been instantiated";
			case ERROR_NON_FATAL: 
				return "Non-fatal error, continuing";
			case ERROR_FAILED_LOAD_LIBRARY: 
				return "Critical libraries couldn't be loaded";
			case ERROR_SECURITY_MANAGER_VIOLATION: 
				return "The Security Manager on this system does not allow me to load one or more critical libraries";
			case ERROR_NO_JAVACURL_HANDLE_AVAILABLE: 
				return "Critical libcurl: no javacurl handle returned";
			case ERROR_NOT_IMPLEMENTED: 
				return "Option/Callback/Method not implmented";
			case ERROR_UNSUPPORTED_PROTOCOL:
				return "Protocol not supported by cURL";
			case ERROR_FAILED_INIT:
				return "cURL failed to initialize";
			case ERROR_URL_MALFORMAT:
				return "Bad URL format";
			case ERROR_COULDNT_RESOLVE_PROXY:
				return "cURL could not resolve proxy host";
			case ERROR_COULDNT_RESOLVE_HOST:
				return "cURL could not resolve host";
			case ERROR_COULDNT_CONNECT:
				return "cURL could not make a connection";
			case ERROR_FTP_WEIRD_SERVER_REPLY:
			case ERROR_FTP_ACCESS_DENIED:
			case ERROR_FTP_USER_PASSWORD_INCORRECT:
			case ERROR_FTP_WEIRD_PASS_REPLY:
			case ERROR_FTP_WEIRD_USER_REPLY:
			case ERROR_FTP_WEIRD_PASV_REPLY:
			case ERROR_FTP_WEIRD_227_FORMAT:
			case ERROR_FTP_CANT_GET_HOST:
			case ERROR_FTP_CANT_RECONNECT:
			case ERROR_FTP_COULDNT_SET_BINARY:
				return "Some sort of FTP error";
			case ERROR_PARTIAL_FILE:
			case 	  ERROR_FTP_COULDNT_RETR_FILE:
			case  ERROR_FTP_WRITE_ERROR:
			case  ERROR_FTP_QUOTE_ERROR:
			case  ERROR_HTTP_RETURNED_ERROR:
			case  ERROR_WRITE_ERROR:
			case  ERROR_MALFORMAT_USER:
			case  ERROR_FTP_COULDNT_STOR_FILE:
			case  ERROR_READ_ERROR:
			case  ERROR_OUT_OF_MEMORY:
			case  ERROR_OPERATION_TIMEOUTED:
			case  ERROR_FTP_COULDNT_SET_ASCII:
			case  ERROR_FTP_PORT_FAILED:
			case  ERROR_FTP_COULDNT_USE_REST:
			case  ERROR_FTP_COULDNT_GET_SIZE:
			case  ERROR_HTTP_RANGE_ERROR:
			case  ERROR_HTTP_POST_ERROR:
			case  ERROR_SSL_CONNECT_ERROR:
			case  ERROR_BAD_DOWNLOAD_RESUME:
			case  ERROR_FILE_COULDNT_READ_FILE:
			case  ERROR_LDAP_CANNOT_BIND:
			case  ERROR_LDAP_SEARCH_FAILED:
			case  ERROR_LIBRARY_NOT_FOUND:
			case  ERROR_FUNCTION_NOT_FOUND:
			case  ERROR_ABORTED_BY_CALLBACK:
			case  ERROR_BAD_FUNCTION_ARGUMENT:
			case  ERROR_BAD_CALLING_ORDER:
			case  ERROR_INTERFACE_FAILED:
			case  ERROR_BAD_PASSWORD_ENTERED:
			case  ERROR_TOO_MANY_REDIRECTS:
			case  ERROR_UNKNOWN_TELNET_OPTION:
			case  ERROR_TELNET_OPTION_SYNTAX:
			case  ERROR_OBSOLETE:
			case  ERROR_SSL_PEER_CERTIFICATE:
			case  ERROR_GOT_NOTHING:
			case  ERROR_SSL_ENGINE_NOTFOUND:
			case  ERROR_SSL_ENGINE_SETFAILED:
			case  ERROR_SEND_ERROR:
			case  ERROR_RECV_ERROR:
			case  ERROR_SHARE_IN_USE:
			case  ERROR_SSL_CERTPROBLEM:
			case  ERROR_SSL_CIPHER:
			case  ERROR_SSL_CACERT:
			case  ERROR_BAD_CONTENT_ENCODING:
			case  ERROR_LDAP_INVALID_URL:
			case  ERROR_FILESIZE_EXCEEDED:
			case  ERROR_FTP_SSL_FAILED:
				  	return "Not done describing this error type";

		}
		// Uh oh...
		return "Unknown error";
	}

	/**
	 * Throws an appropriate exception based on the passed in error code.
	 *
	 * @param code the CURL error code
	 */
	public static void error (int code) {
		error (code, null);
	}

	/**	 
 	 * Throws an appropriate exception based on the passed in error code.
	 * The <code>throwable</code> argument should be either null, or the
	 * throwable which caused CURL to throw an exception.
	 */
	public static void error (int code, Throwable throwable) {
		error (code, throwable, null);
	}

	
	/**
	 * Throws an appropriate exception based on the passed in error code.
	 * The <code>throwable</code> argument should be either null, or the
	 * throwable which caused CURL to throw an exception.
	 * <p>
	 *
	 * @param code the CURL error code.
	 * @param throwable the exception which caused the error to occur.
	 * @param detail more information about error.
	 *
	 * @see CURLError
	 * @see CURLException
	 * @see IllegalArgumentException
	 */
	public static void error (int code, Throwable throwable, String detail) {
		/*
		* This code prevents the creation of "chains" of CURLErrors and
		* CURLExceptions which in turn contain other CURLErrors and 
		* CURLExceptions as their throwable. This can occur when low level
		* code throws an exception past a point where a higher layer is
		* being "safe" and catching all exceptions. (Note that, this is
		* _a_bad_thing_ which we always try to avoid.)
		*
		* On the theory that the low level code is closest to the
		* original problem, we simply re-throw the original exception here.
		*/
		if (throwable instanceof CURLError) throw (CURLError) throwable;
		if (throwable instanceof CURLException) throw (CURLException) throwable;

		String message = findErrorText (code);
		if (detail != null) message += detail;
		switch (code) {
			
			/* Illegal Arguments (non-fatal) */
			case ERROR_BAD_ARGUMENT:
			case ERROR_NO_CALLBACK_INSTANCE: { 
				throw new IllegalArgumentException (message);
			}
			
			/* CURL Errors (non-fatal) */
			case ERROR_NON_FATAL:
			case ERROR_NULL_ARGUMENT:
			case ERROR_URL_MALFORMAT:
			case ERROR_COULDNT_RESOLVE_PROXY: 
			case ERROR_UNSUPPORTED_PROTOCOL: {
				CURLException exception = new CURLException (code, message);
				exception.throwable = throwable;
				throw exception;
			}
			
			/* OS Failure/Limit (fatal)*/
			case ERROR_NO_JAVACURL_HANDLE_AVAILABLE:
			case ERROR_FAILED_LOAD_LIBRARY:
			//FALL THROUGH
			
			/* CURL Failure (fatal) */
			case ERROR_FAILED_INIT:
			case ERROR_SECURITY_MANAGER_VIOLATION:
			case ERROR_NOT_IMPLEMENTED:
			case ERROR_UNSPECIFIED: {
				CURLError error = new CURLError (code, message);
				error.throwable = throwable;
				throw error;
			}
		}
		
		/* Unknown/Undefined Error */
		CURLError error = new CURLError (code, message);
		error.throwable = throwable;
		throw error;
	}
}