IMPORTANT: This is not a tutorial for developing a jni interface to libcurl. In fact, this is no tutorial. In
this README I help you to integrate a Plugin Project to Eclipse 3.0.1 and/or install a functional plugin (notice
I did not say 'fully' functional, as i have not fully tested the jni itself). I do know that the HTTP functions
of libcurl 'seem' to work. I haven't tried testing the other functionalities of libcurl... yet 8^).

For use with Eclipse 3.0.1 or greater. This plugin will not work with Eclipse 2.x due to using the OSGi bundle
manifest format. I don't have 2.x so I have no plans to integrate it. I'm guessing that if you know what you're
doing, playing with Eclipse plug-ins, you'll be able to figure out how to get a 2.x plug-in without having me
to confuse you.


**********
This plugin has two parts:

	One is a full importable Plugin Project into the Eclipse IDE. This will allow you to make any changes
you want to the java native interface. Note that if you add functionality and methods to CurlGlue.java you 
may also have to change javacurl.c and re-generate a new org_curl_CurlGlue.h header using the jni.bat I have
provided. Then again, you are playing with plugins and libcurl jni, then you probably already know what you
are doing.
	The second is an installable plugin for Eclipse 3.0.1. If you don't want to mess with the Plugin Project
you simply extract this to your <drive>:\${eclipse.dir}. It should extract into the eclipse\plugins folder by
itself.


**************
Import Eclipse Plugin Project Instructions:
	1) Extract org.curl-1.0.zip to some place other than your workspace folder, you cannot import if you do 
not do so. From inside Eclipse: Select File->Import and select "Existing Project into Workspace". Browse to
where you extracted the project (or type it in). Eclipse does the rest. 
	2) In the Package Explorer you will see a project called org.curl-1.0. It is fully ready to be exported 
to plugin status. Right click on package org.curl-1.0 and choose Export. Select "Deployable plug-ins and fragments".
In the next dialog select the plugin project, "Deploy as: a directory structure", and "Destination: c:\eclipse". Be
sure to replace c:\eclipse with your particular Eclipse install location. If you followed these simple instructions
to the letter, you should now have a libcurl jni plug-in. I'll tell you how to use it after I explain installing
the plug-in alone.

**************
Import Eclipse Plugin Instructions:
	1) Extract org.curl-1.0_eclipse30.zip to your eclipse install directory. For example, if you are like me
and have eclipse installed to c:\eclipse, you'd extract to: c:\eclipse! You should now have the folder structure
eclipse\plugins\org.curl_1.0.0.
	2) That's it. Start Eclipse.

********************
Using org.curl_1.0.0 in your Eclipse Project:
	1) For any Java Project: right click on the project in the Package Explorer and select Properties. Select
"Java Build Path" from the list on the left, and the "Libraries" tab on the right. You need to "Add External Jars",
navigate to the plugins\org.curl_1.0.0 folder and select libcurl.jar. Click on OK. Back in the Package Explorer,
you should now see libcurl.jar along side the eclipse jar icon, probably under JRE System Library. If you do not
then you should probably read the Eclipse manual and learn how to include plug-ins with your project.
	2) If you suceeded in including libcurl.jar then you need to "import org.curl.*;".
	3) You need to add -Djava.library.path=<YOUR_INSTALL>\eclipse\plugins\org.curl_1.0.0\os\win32\x86 to the
VM arguments of your Run Configuration.

Note that you will have to have at least one instance of CurlWrite if you want to see what libcurl.dll returns.

****************
For illustration, I've include the project folder of test.java, the test file included by the author. Import this
project from the Package Explorer as an existing project, again be sure to extract the project to some place OTHER
than your eclipse workspace. Eclipse will NOT allow you to import from your workspace.

In the near
future I plan on adding javadoc to the library and I'll probably convert many of the C samples so I can learn
more myself. I'll be posting stuff as I make major milestones.


********************
N.B. =>> Disclaimer: This is my first real programming project in 7 years. Libcurl is open source and is released
under a MIT/X derivative license. Please read more at http://curl.haxx.se/docs/copyright.html. As I did not change 
any of the original libcurl code, I am not responsible for mishaps due to libcurl integration with your 
programming environment. If you happen to destroy your particular install of Eclipse in the process, then I'm of
the opinion that we learn the most from the biggest mistakes. I know I have. My only advice is to think your way
through any kind of install and planning ahead. Oh yeah, and make backups... oh man, make backups!!!

Vic Hanson
vhanson@securetradelink.com